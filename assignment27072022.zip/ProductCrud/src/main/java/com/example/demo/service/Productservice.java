package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Product;

public interface Productservice {
   public List<Product> findAll() ;

public static void saveOrUpdate(Product pro) {
	// TODO Auto-generated method stub
	
}

public static void deleteById(int id) {
	// TODO Auto-generated method stub
	
}
   
   
}
